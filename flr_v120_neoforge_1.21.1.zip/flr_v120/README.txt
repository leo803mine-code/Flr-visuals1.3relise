FLR Visuals 1.2.0 (NeoForge 1.21.1)
Push to GitHub -> Actions -> artifact "flrvisuals" (jar). Menu: Right Shift.
